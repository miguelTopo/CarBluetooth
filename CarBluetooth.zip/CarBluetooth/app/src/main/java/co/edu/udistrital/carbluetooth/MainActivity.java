package co.edu.udistrital.carbluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 10;

    BluetoothAdapter mBluetoothAdapter;
    List<String> mArrayAdapter;

    BluetoothDevice device;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        enableBluetoothCapabilities();
        initBroadcastReceiver();

        if (mBluetoothAdapter.startDiscovery())
            System.out.println("funcionó");

        System.out.println(" A CONECTAR");

        if (device != null) {
            ConnectThread thread = new ConnectThread(device, mBluetoothAdapter);
            thread.start();
        }
    }

    private void initBroadcastReceiver() {
        final BroadcastReceiver mReceived = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equalsIgnoreCase(action)) {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    mArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                }
            }
        };
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mReceived, filter);
    }

    private void validateDevicesSync() {
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            //Existen dispositivos sincronizados
            for (BluetoothDevice d : pairedDevices) {
                if (mArrayAdapter == null)
                    mArrayAdapter = new ArrayList<>(1);
                if (d.getName().equalsIgnoreCase("HC-05")) {
                    device = d;
                    mArrayAdapter.add(d.getName() + "\n" + d.getAddress());
                    break;
                }
            }
        }
    }


    private void enableBluetoothCapabilities() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            //Device does not support Bluetooth
            System.out.println("Este dispositivo no soporte Bluetooth");
        } else {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtnIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtnIntent, REQUEST_ENABLE_BT);
            } else
                validateDevicesSync();
        }
    }

}
